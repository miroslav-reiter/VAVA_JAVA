/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

// import java.io.IOException;

public class Frisbee {
    public static void main(String[] args) throws IOException{
        int x = 0;
        // insert code here
        
        System.out.println(7/x);
    }
}
