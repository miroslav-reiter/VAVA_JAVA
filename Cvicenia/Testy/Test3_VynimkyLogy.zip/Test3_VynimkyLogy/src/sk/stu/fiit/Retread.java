/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */

class MyException extends Exception {}

class Tire {
    void doStuff(){}
}

public class Retread extends Tire {
    public static void main(String[] args) {
        new Retread().doStuff();
    }

    void doStuff() throws ArithmeticException{
        System.out.println(7/0);
    }
}
