/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

import java.util.*;

/**
 *
 * @author Administrator
 */
public class Fortress {
    private String name;
    private ArrayList<Integer> list;  

    public Fortress() {
        list = new ArrayList<Integer>();
    }

    public String getName() {
        return name;
    }
    
    void addToList(int x){
        list.add(x);
    }
    
    ArrayList getList(){
        return list;
    }
    
}
