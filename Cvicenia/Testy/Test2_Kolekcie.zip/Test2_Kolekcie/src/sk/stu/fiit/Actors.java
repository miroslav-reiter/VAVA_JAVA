/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Actors {
    public static void main(String[] args) {
        char[] ca = {0x4e, '\u004e', 78};
    }
}
