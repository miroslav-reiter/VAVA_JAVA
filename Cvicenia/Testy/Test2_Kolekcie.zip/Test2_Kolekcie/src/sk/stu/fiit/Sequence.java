/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

// Fix Import Ctrl + Shift + I
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class Sequence {
    public static void main(String[] args) {
        // newo
        ArrayList<String> myList = new ArrayList();
        myList.add("apple");
        myList.add("carrot");
        myList.add("banana");
        myList.add(1, "plum");
        // soutv
        System.out.print( myList);
        
        
    }
}
