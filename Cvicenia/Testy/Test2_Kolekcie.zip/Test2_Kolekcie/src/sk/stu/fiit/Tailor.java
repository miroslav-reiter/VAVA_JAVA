/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Tailor {
    // main, psvm
    public static void main(String[] args) {
        byte[][] ba = {{1,2,3,4}, {1,2,3}};
        // soutv
        System.out.println(ba[1].length + " " + ba.length);
    }
}
