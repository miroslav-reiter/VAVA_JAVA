/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package testo.stu;

/**
 *
 * @author Administrator
 */
public class STU {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
