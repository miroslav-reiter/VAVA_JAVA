/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rb;

import java.util.*;

/**
 *
 * @author Administrator
 */
public class KeyValue {
    public static void main(String[] args) {
        ResourceBundle rb = ResourceBundle.getBundle("rb.Bundle", Locale.getDefault());
        // insert code here
        // Object obj = rb.getObject("123");
        Object obj =  rb.getString("123");
        
        
    }
}
