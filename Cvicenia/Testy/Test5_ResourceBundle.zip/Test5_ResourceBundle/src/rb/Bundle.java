/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rb;

import java.util.ListResourceBundle;

/**
 *
 * @author Administrator
 */
public class Bundle extends ListResourceBundle {

    @Override
    protected Object[][] getContents() {
        return new Object[][]{{"123", 456}};
    }

}
