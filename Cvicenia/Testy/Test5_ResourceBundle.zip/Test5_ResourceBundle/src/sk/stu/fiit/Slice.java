/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

import java.text.*;

/**
 *
 * @author Administrator
 */
public class Slice {
    public static void main(String[] args) {
        String s = "987,123456";
        double d = 987.123456d;
        NumberFormat nf =  NumberFormat.getInstance();
        
        nf.setMaximumFractionDigits(5);
        System.out.println(nf.format(d) + " ");
        
        try {
            System.out.println(nf.parse(s));
        } catch (Exception e) {
            System.out.println("got exc");
        }
    }
  
}
