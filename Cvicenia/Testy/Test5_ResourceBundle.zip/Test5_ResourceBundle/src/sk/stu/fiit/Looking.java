/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

import java.util.*;

/**
 *
 * @author Administrator
 */
public class Looking {

    public static void main(String[] args) {
        String input = "1 2 a 3 45 6";
        Scanner sc = new Scanner(input);
        int x = 0;
        do {
            x = sc.nextInt();
            System.out.print(x  + " ");
        } while (x != 0);
    }
}
