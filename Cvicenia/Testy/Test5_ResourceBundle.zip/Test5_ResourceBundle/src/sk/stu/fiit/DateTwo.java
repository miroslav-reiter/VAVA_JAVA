/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

import java.text.*;
import java.util.*;

/**
 *
 * @author Administrator
 */
public class DateTwo {
    public static void main(String[] args) {
        Date d = new Date(1_119_280_000_000L );
        DateFormat df = DateFormat.getDateInstance(DateFormat.LONG, Locale.GERMANY);
        
        System.out.println(df.format(d));
    }
}
