/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Stone {
    public static void main(String[] args) {
        String s = "abc";
        System.out.println(">" + doStuff(s) + "<");
    }

    static String doStuff(String s) {
        s = s.concat(" eh h ");
        return s.strip();
    }
}
