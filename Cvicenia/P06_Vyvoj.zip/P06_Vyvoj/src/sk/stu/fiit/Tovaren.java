/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Tovaren {

    int pocetZamestancov /*= 300*/;
    String adresa /*= "Vajnorska"*/;
    boolean otvorena /*= true*/;

    public Tovaren(int pocetZamestancov, String adresa, boolean otvorena) {
        this.pocetZamestancov = pocetZamestancov;
        this.adresa = adresa;
        this.otvorena = otvorena;
    }

    public Tovaren(int pocetZamestancov, String adresa) {
        this.pocetZamestancov = pocetZamestancov;
        this.adresa = adresa;
    }

    public Tovaren(String adresa, boolean otvorena) {
        this.adresa = adresa;
        this.otvorena = otvorena;
    }

    private Tovaren() {
        System.out.println("Hura tovaren je na svete...");
    }

    // SFM
    public static Tovaren generujTovaren() {
        return new Tovaren();
    }

    public static void main(String[] args) {
        // 1. newo
        Tovaren prvaTovaren = new Tovaren();

        // 2. SFM Jednoducha tovarenska metoda
        Tovaren.generujTovaren();
    }

}
