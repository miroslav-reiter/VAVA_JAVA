/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
@FunctionalInterface
public interface ITester {
    public String vytvaraReport();
    
    public default String vytvaraTest(){
        return "BDD";
    }
    
    public default void vypisAhoj(){
        System.out.println("Hello...");
    }
}
