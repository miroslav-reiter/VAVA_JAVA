/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Main implements IProgramator, ITester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // newo
        Main objektik = new Main();
//        objektik.piseKod("lalalsdfhdsk");
        objektik.vypisAhoj();

//        Tovaren tvSamsung = new Tovaren();
        Tovaren.generujTovaren();
        System.out.println(Integer.parseInt("56"));
    }

    @Override
    public void vypisAhoj() {
        ITester.super.vypisAhoj(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void piseKod(String zdrojak) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String vytvaraReport() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
