/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        byte b = 127;
        System.out.println("b = " + b);
        System.out.println("Velkost v bitoch = " + Byte.SIZE);
        System.out.println("Velkost v bytoch = " + Byte.BYTES);
        System.out.println("Minimalna hodnota = " + Byte.MIN_VALUE);
        System.out.println("Maximalna hodnota = " + Byte.MAX_VALUE);
        System.out.println("Type = " + Byte.TYPE);
        
        short s = 32767;
        System.out.println("\ns = " + s);
        System.out.println("Velkost v bitoch = " + Short.SIZE);
        System.out.println("Velkost v bytoch = " + Short.BYTES);
        System.out.println("Minimalna hodnota = " + Short.MIN_VALUE);
        System.out.println("Maximalna hodnota = " + Short.MAX_VALUE);
        System.out.println("Type = " + Short.TYPE);
        
        int i = 123_456_789;
        System.out.println("\ni = " + i);
        System.out.println("Velkost v bitoch = " + Integer.SIZE);
        System.out.println("Velkost v bytoch = " + Integer.BYTES);
        System.out.println("Minimalna hodnota = " + Integer.MIN_VALUE);
        System.out.println("Maximalna hodnota = " + Integer.MAX_VALUE);
        System.out.println("Type = " + Integer.TYPE);
        
        float f = 3.99F;
        long l = 123_456_789_000L;
        
        System.out.println("\nf = " + f);
        System.out.println("Velkost v bitoch = " + Float.SIZE);
        System.out.println("Velkost v bytoch = " + Float.BYTES);
        System.out.println("Minimalna hodnota = " + Float.MIN_VALUE);
        System.out.println("Maximalna hodnota = " + Float.MAX_VALUE);
        System.out.println("Nekonecno - = " + Float.NEGATIVE_INFINITY);
        System.out.println("Nekonecno + = " + Float.POSITIVE_INFINITY);
        System.out.println("NaN + = " + Float.NaN);
        System.out.println("Min exponent + = " + Float.MIN_EXPONENT);
        System.out.println("Max exponent + = " + Float.MAX_EXPONENT);
        System.out.println("Type = " + Float.TYPE);
        
        System.out.println(0. / 0);
        
        boolean boo = true;
        System.out.println("boo = " + boo);
        System.out.println("false = " + Boolean.FALSE);
        System.out.println("true = " + Boolean.TRUE);
        System.out.println("type = " + Boolean.TYPE);
        
        var temp = 5;
        var temp2 = "Karol";
        
        char oblubenePismeno = 'a';
        System.out.println("oblubenePismeno = " + oblubenePismeno);
        System.out.println(Character.BYTES);
        System.out.println(Character.MIN_VALUE);
        System.out.println(Character.MAX_VALUE);
        
        
        
    }
    
}
