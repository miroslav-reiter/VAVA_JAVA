package sk.stu.fiit;

public class Gotcha {

    public static void main(String[] args) {
// insert code here
    }

    void go() {
        go();
    }
}


//I. new Gotcha().go();
//II. try { new Gotcha().go(); }
//catch (Error e) { System.out.println("ouch"); }
//III. try { new Gotcha().go(); }
//catch (Exception e) { System.out.println("ouch"); }

/*

B and E are correct. First off, go() is a badly designed recursive method, guaranteed to
cause a StackOverflowError. Since Exception is not a superclass of Error, catching an
Exception will not help handle an Error, so fragment III will not complete normally. Only
fragment II will catch the Error.

*/