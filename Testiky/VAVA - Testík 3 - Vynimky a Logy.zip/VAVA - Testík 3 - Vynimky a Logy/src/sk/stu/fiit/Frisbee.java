package sk.stu.fiit;

public class Frisbee {

    public static void main(String[] args) throws Exception {
        // insert code here
        int x = 0;

        System.out.println(7 / x);
    }
}

//I. public static void main(String[] args) {
//II. public static void main(String[] args) throws Exception {
//III. public static void main(String[] args) throws IOException {
//IV. public static void main(String[] args) throws RuntimeException {

/*

D is correct. This is kind of sneaky, but remember that we're trying to toughen you up for
the real exam. If you're going to throw an IOException, you have to import the java.io package
or declare the exception with a fully qualified name.

*/