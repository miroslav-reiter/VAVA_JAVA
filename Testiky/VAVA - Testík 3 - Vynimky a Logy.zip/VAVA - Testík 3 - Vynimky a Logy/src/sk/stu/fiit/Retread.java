package sk.stu.fiit;
class MyException extends Exception {}
class Tire {
    void doStuff() {}
}
public class Retread extends Tire {
    public static void main(String[] args) {
        new Retread().doStuff();
    }
// insert code here
    void doStuff() throws RuntimeException {
        System.out.println(7 / 0);
    }
}


//I. void doStuff() {
//II. void doStuff() throws MyException {
//III. void doStuff() throws RuntimeException {
//IV. void doStuff() throws ArithmeticException {

/*

C and D are correct. An overriding method cannot throw checked exceptions that are
broader than those thrown by the overridden method. However, an overriding method can
throw RuntimeExceptions not thrown by the overridden method

*/