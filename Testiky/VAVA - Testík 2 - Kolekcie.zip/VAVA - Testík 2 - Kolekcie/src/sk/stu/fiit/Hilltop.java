/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

public class Hilltop {

    public static void main(String[] args) {
        String[] horses = new String[5];
        horses[4] = null;
        for (int i = 0; i < horses.length; i++) {
            if (i < args.length) {
                horses[i] = args[i];
            }
            System.out.print(horses[i].toUpperCase() + " ");
        }
    }
}

/*
2 - Uprav config
And, if the code compiles, the command line:
java Hilltop eyra vafi draumur kara
// -> HILLTOP EYRA VAFI DRAUMUR KARA a potom java.lang.NullPointerException

D is correct. The horses array's first four elements contain Strings, but the fifth is null,
so the toUpperCase() invocation for the fifth element throws a NullPointerException.
*/
