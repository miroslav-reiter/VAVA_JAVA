package sk.stu.fiit;
// Este nedavaj...
class Dozens {
    int[] dz = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
}
public class Eggs {
    public static void main(String[] args) {
        Dozens[] da = new Dozens[3];
        da[0] = new Dozens();
        Dozens d = new Dozens();
        da[1] = d;
        d = null;
        da[1] = null;
        // do stuff
    }
}

/*
6 
Which two are true about the objects created within main(), and which are eligible for garbage
collection when line 14 is reached?

A. Three objects were created
B. Four objects were created
    C. Five objects were created
D. Zero objects are eligible for GC
E. One object is eligible for GC
    F. Two objects are eligible for GC
G. Three objects are eligible for GC

C and F are correct. da refers to an object of type "Dozens array" and each Dozens object
that is created comes with its own "int array" object. When line 14 is reached, only the second
Dozens object (and its "int array" object) are not reachable.

*/