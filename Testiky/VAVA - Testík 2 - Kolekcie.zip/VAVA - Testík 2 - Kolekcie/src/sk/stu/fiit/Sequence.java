package sk.stu.fiit;

import java.util.*;

public class Sequence {

    public static void main(String[] args) {
        ArrayList<String> myList = new ArrayList<String>();
        myList.add("apple");
        myList.add("carrot");
        myList.add("banana");
        myList.add(1, "plum");
        System.out.print(myList);
    }
}


/*
// Show inline hints
5.
What is the result?
[apple, plum, carrot, banana]

B is correct. ArrayList elements are automatically inserted in the order of entry; they are
not automatically sorted. ArrayLists use zero-based indexes and the last add() inserts a new
element and shifts the remaining elements back.

*/