package sk.stu.fiit; import java.util.*;
class Fortress {
private String name;
private ArrayList<Integer> list;
Fortress() { list = new ArrayList<Integer>(); }

String getName() { return name; }
void addToList(int x) { list.add(x); }
ArrayList getList() { return list; }
}


/*
F is correct (line 9). When encapsulating a mutable object like an ArrayList, 
your getter must return a reference to a copy of the object, 
not just the reference to the original object.
OCA Objectives 2.6 and 2.7
*/

/*

When encapsulating a
mutable object like a StringBuilder, or an array, or an ArrayList, if you want to
let outside classes have a copy of the object, you must actually copy the object and
return a reference variable to the object that is a copy. If all you do is return a copy
of the original object's reference variable, you DO NOT have encapsulation



*/