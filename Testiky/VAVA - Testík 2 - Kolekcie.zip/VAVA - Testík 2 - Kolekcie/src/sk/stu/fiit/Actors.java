/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author miros
 */
public class Actors {

    public static void main(String[] args) {
        char[] ca = {0x4e, \u004e, 78};
        System.out.println((ca[0] == ca[1]) + " " + (ca[0] == ca[2]));
    }
}

/*
    3
E. Compilation fails
E is correct. The Unicode declaration must be enclosed in single quotes: '\u004e'. If this
were done, the answer would be A, but knowing that equality isn't on the OCA exam

*/