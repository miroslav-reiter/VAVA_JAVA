/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

import java.util.Scanner;
import javax.swing.JFrame;

/**
 *
 * @author miros
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        JFrame okno = new JFrame();
//        int dialogOdpoved = JOptionPane.showConfirmDialog(okno, "Das si cas na ranajky?", "Hotel volba ranajky", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
//
//        // Tradicny if/else
//        if (dialogOdpoved == JOptionPane.YES_OPTION) {
//            JOptionPane.showMessageDialog(okno, "Caj je super...");
//        } else {
//            JOptionPane.showMessageDialog(okno, "Diky, nieco ine...");
//        }

        // Tradicny if/elseif/else
//        if (dialogOdpoved == JOptionPane.YES_OPTION) {
//            JOptionPane.showMessageDialog(okno, "Caj je super...");
//        } else if (dialogOdpoved == JOptionPane.NO_OPTION) {
//            JOptionPane.showMessageDialog(okno, "Diky, nieco ine...");
//        } else {
//            JOptionPane.showMessageDialog(okno, "Sme troska mimo...");
//        }
        // Tradicny switch (v case su staticke final datove zlozky)
//        switch (dialogOdpoved) {
//            case JOptionPane.YES_OPTION:
//                JOptionPane.showMessageDialog(okno, "Caj je super...");
//                break;
//            case JOptionPane.NO_OPTION:
//                JOptionPane.showMessageDialog(okno, "Diky, nieco ine...");
//                break;
//            default:
//                JOptionPane.showMessageDialog(okno, "Sme troska mimo...");
//                break;
//        }
        // Java 12 - switch rule
//        switch (dialogOdpoved) {
//            case JOptionPane.YES_OPTION ->
//                JOptionPane.showMessageDialog(okno, "Caj je super...");
//            case JOptionPane.NO_OPTION ->
//                JOptionPane.showMessageDialog(okno, "Diky, nieco ine...");
//            default ->
//                JOptionPane.showMessageDialog(okno, "Sme troska mimo...");
//        }
        System.out.println(getHodnotaYield("a"));
        System.out.println(getHodnotaYield("b"));
        // Thread.yield();
        // kukni do Triedy thread

        System.out.println(getHodnotaYield2("a"));
        System.out.println(getHodnotaYield2("b"));

        // Java 14 - switch case block in an expression
        // switch block can return a value. With traditional switch statement, 
        // we have to use temporary variable as shown in the following code example:
        int month = 1;
        int days = switch (month) {
            case 1, 3, 5, 7, 8, 10, 12 ->
                31;
            case 4, 6, 9 ->
                30;
            case 2 ->
                28;
            default ->
                0;
        };

        // Alebo takto...
        System.out.println(
                switch (month) {
            case 1, 3, 5, 7, 8, 10, 12 ->
                31;
            case 4, 6, 9 ->
                30;
            case 2 ->
                28;
            default ->
                0;
        }
        );
        // alebo takto
        int mesiac = 1;
        int den = switch (mesiac) {
            case 1, 3, 5, 7, 8, 10, 12 ->
                31;
            case 4, 6, 9 ->
                30;
            case 2 -> {
                Scanner scanner = new Scanner(System.in);
                System.out.print("Zadaj rok: ");
                int rok = scanner.nextInt();

                if (rok % 4 == 0) {
                    yield 29;
                } else {
                    yield 28;
                }
            }
            default ->
                0;
        };

    }

    //  V Java 13 môžeme použiť yield na vrátenie hodnoty.
    /*
    Metóda yield () je statická metóda triedy Thread, ktorá 
    dokáže zastaviť práve vykonávané vlákno     
    a dá šancu ďalším čakajúcim vláknam s rovnakou prioritou.
     */
    private static int getHodnotaYield(String mode) {
        int result = switch (mode) {
            case "a", "b":
                yield 1;
            /* break 1 */ // Java 13, value breaks are superseded by 'yield' statements
            case "c":
                yield 2;
            case "d", "e", "f":
                // do something here...
                System.out.println("Supports multi line block!");
                yield 3;
            default:
                yield -1;
        };
        return result;
    }

    private static int getHodnotaYield2(String mode) {
        int result = switch (mode) {
            case "a", "b" -> {
                yield 1;
            }
            case "c" -> {
                yield 2;
            }
            case "d", "e", "f" -> {
                // do something here...
                System.out.println("Supports multi line block!");
                yield 3;
            }
            default -> {
                yield -1;
            }
        };
        return result;
    }

}
