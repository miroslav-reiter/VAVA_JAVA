/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Televizor {

//    private String znacka;
    private String znacka = "Sony";
    private double cena = 0.0;
    private float uhlopriecka = (float) 0;
    private boolean isZapnuty = false;
    private int hmotnost = 0;
    private int hlasitost = 100;

    public String getZnacka() {
        return znacka;
    }

    public static void main(String[] args) {
        System.out.println("Som v TV...");

        // newo
        Televizor tvSonyKDLx56 = new Televizor();
        Televizor tvSamsungX36 = new Televizor();

        System.out.println(tvSamsungX36.toString());
        System.out.println(tvSonyKDLx56.toString());

        System.out.println(tvSonyKDLx56.znacka);
        System.out.println(tvSonyKDLx56.getZnacka());

        System.out.println(tvSonyKDLx56.hmotnost);
        System.out.println(tvSonyKDLx56.uhlopriecka);
        System.out.println(tvSonyKDLx56.cena);
        System.out.println(tvSonyKDLx56.isZapnuty);

    }
}
