/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(KontrolaTypov.typeof(963));
        
        // newo
        Scanner objVstup = new Scanner(System.in);
        System.out.println("Zadaj svoje meno: ");
        String meno = objVstup.next();
        System.out.println("Ahoj " + meno);
        
        System.out.println("Zadaj svoj vek: ");
        int vek = objVstup.nextInt();
        System.out.println("Mas " + vek + " rokov");
        
    }
    
}
