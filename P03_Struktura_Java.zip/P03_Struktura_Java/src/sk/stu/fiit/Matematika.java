/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class Matematika {
    
    public static void main(String[] args) {
        System.out.println(Math.PI);
        System.out.println(Math.E);
        System.out.println(Math.abs(-50));
        System.out.println(Math.cbrt(125));
        System.out.println(Math.sqrt(81));
        System.out.println(Math.pow(2,5));
        System.out.println(Math.ceil(3.001));
        System.out.println(Math.floor(3.001));
        System.out.println(Math.addExact(5, 2));
        System.out.println(5 + 2);
//        System.out.println(Math.incrementExact(Integer.MAX_VALUE));
        System.out.println(Math.decrementExact(5));
        System.out.println(5/2);
        System.out.println(Math.floorDiv(5, 2));
        
        System.out.println(5 % 2);
        System.out.println(Math.floorMod(5, 2));
        System.out.println(Math.random());
        
    }
}
