/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sk.stu.fiit;

/**
 *
 * @author Administrator
 */
public class KontrolaTypov {

    static Class typeof(Integer i) {
        return i.getClass();
    }

    static Class typeof(Character c) {
        return c.getClass();
    }

    static Class typeof(Float f) {
        return f.getClass();
    }

    static Class typeof(Double d) {
        return d.getClass();
    }

    static Class typeof(Long l) {
        return l.getClass();
    }

    static Class typeof(String s) {
        return s.getClass();
    }

    // psvm, main
    public static void main(String[] args) {
        System.out.println(KontrolaTypov.typeof(42));
        System.out.println(KontrolaTypov.typeof(42.));
        System.out.println(KontrolaTypov.typeof(42.f));
        System.out.println(KontrolaTypov.typeof("42"));
        System.out.println(KontrolaTypov.typeof(42L));
        System.out.println(KontrolaTypov.typeof('a'));
        
        assert (5 > 10) : "Nepreslo to...";
        System.out.println("\nJupi test presiel...");

    }

}
