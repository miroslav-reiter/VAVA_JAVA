package sk.stu.fei;

import sk.stu.fiit.KontrolaTypov;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class Main {
    public static void main(String[] args) {
        KontrolaTypov.main(args);
        
        switch ("Karol") {
            case "Karol":
                System.out.println("Som Karol");
                break;
            case "Ivan":
                System.out.println("Som Ivan");
                break;
            default:
                throw new AssertionError();
        }
    }
}
